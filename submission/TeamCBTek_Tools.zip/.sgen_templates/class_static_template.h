/*
    $CLASS_NAME.h
    $COPYRIGHT
*/
#pragma once
$INCLUDES_H
$BEGIN_NAMESPACE

class $CLASS_NAME $PARENT_CLASSES
{
public:
private:
    //! Private constructor for $CLASS_NAME
	$CLASS_NAME();

    //! Private copy constructor for $CLASS_NAME
	$CLASS_NAME(const $CLASS_NAME &);

	//! Private destructor for $CLASS_NAME
	~$CLASS_NAME();	
};
$END_NAMESPACE