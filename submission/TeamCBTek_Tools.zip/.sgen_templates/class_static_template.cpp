/*
    $CLASS_NAME.cpp
    $COPYRIGHT
*/
//----------------------------------------
//$TIMESTAMP
//----------------------------------------

#include "$CLASS_NAME.h"

$BEGIN_NAMESPACE


$END_NAMESPACE

